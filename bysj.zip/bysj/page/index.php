<!DOCTYPE html>
<html>
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=utf-8" /><!-- /Added by HTTrack -->
<head>
    <meta charset="utf-8">
    <meta name="baidu-site-verification" content="kbH4w0nY6v" />
    <title>
    绍兴市妙斯食品商行    </title>
    <meta name="description" content="妙斯食品，珍珠奶茶原料、冷冻品休闲小吃原料、奶茶店开店设备、器具器皿供应">
    <meta name="keywords" content="妙斯食品，珍珠奶茶原料、冷冻品休闲小吃原料、奶茶店开店设备、器具器皿供应"/>

    <meta name="viewport" content="width=device-width">
    <meta name="baidu-site-verification" content="ej8YOYdfW7" />
    <link rel="shortcut icon" href="favicon.ico">
    <link rel="stylesheet" href="../static/milk/css/until.css" media="all" />
    <link rel="stylesheet" href="../static/milk/css/grid.css">
    <link rel="stylesheet" href="../static/milk/css/style.css">
    <link rel="stylesheet" href="../static/milk/css/normalize.css">
    <script src="../static/milk/js/jquery.min.js"></script>
    <script>window.jQuery || document.write('<script src="../static/milk/js/jquery-1.8.3.min.js"><\/script>')</script>
    <script src="../static/milk/js/html5.js"></script>
    <script src="../static/milk/js/main.js"></script>
    <script src="../static/milk/js/selectBox.js"></script>
    <script src="../static/milk/js/jquery.carouFredSel-5.2.2-packed.js"></script>
    <script src="../static/milk/js/jquery.jqzoom-core.js"></script>

    <script type="text/javascript" src="../js/custom/system.min.js"></script>
    <script>
        system.base_url = 'index.php';
        system.user_id = '0';
    </script>
 
    
</head>
<body>

   
  <header>
        <div class="container_12">
            <div class="grid_3">
                <hgroup>
                    <h1 id="site_logo"><a href="index.php" title=""><img src="../static/milk/img/miaosi.png" width="155" height="66" alt="Tea and milk"></a></h1>
                  
                </hgroup>
            </div><!-- .grid_3 -->

            <div class="grid_9">
                <div class="top_header">
                    <div class="welcome">
                                           </div><!-- .welcome -->
                    
                    <div class="btns">
                        <ul>
                        	<li><a href="javascript:;" onclick="setHomepage()">设为首页</a></li>
                        	<li><a href="javascript:;" onclick="AddFavorite('http://www.sxmiaosi.com/', '绍兴市妙斯食品商行')">加入收藏</a></li>
                        </ul>
                    </div>
                            

                    </form><!-- .search -->
                </div><!-- .top_header -->

                <nav class="primary">
                    <ul>
                        <li class="curent"><a href="index.php">网站首页</a></li>
                        <li class=""><a href="../page/about.html">公司介绍</a></li>
                        <li class=""><a href="../page/train.html">技术培训</a></li>
<!--                         <li class="parent"> -->
<!--                             <a href="catalog_grid.html">Spray</a> -->
<!--                             <ul class="sub"> -->
<!--                                 <li><a href="catalog_grid.html">For home</a></li> -->
<!--                                 <li><a href="catalog_grid.html">For Garden</a></li> -->
<!--                                 <li><a href="catalog_grid.html">For Car</a></li> -->
<!--                                 <li><a href="catalog_grid.html">Other spray</a></li> -->
<!--                             </ul> -->
<!--                         </li> -->
                        <li class=""><a href="../page/employ.html">人才招聘</a></li>
                        <li class=""><a href="../page/contact.html">联系我们</a></li>
                
                    </ul>
                </nav><!-- .primary -->
            </div><!-- .grid_9 -->
        </div>
    </header>
  
<script src="../static/milk/js/jquery.SuperSlide.2.1.1.js"></script>

  
  <div class="banner-box">
	<div class="bd">
        <ul style="width: 100%!important;">        
          	    
            <li style="width: 100%!important;">
                <div class="m-width">
            <img src="../uploads/milk/widget/gRFoC.jpg" width="100%" height="385" />                </div>
            </li>
              	    
            <li style="width: 100%!important;">
                <div class="m-width">
            <img src="../uploads/milk/widget/C4yqs.jpg" width="100%" height="439" />                </div>
            </li>
            
                   
         
        </ul>
    </div>
    <div class="banner-btn">
        <a class="prev" href="javascript:void(0);"></a>
        <a class="next" href="javascript:void(0);"></a>
        <div class="hd"><ul></ul></div>
    </div>
</div><!-- #slider_body -->
  <script type="text/javascript">
$(document).ready(function(){

	$(".prev,.next").hover(function(){
		$(this).stop(true,false).fadeTo("show",0.9);
	},function(){
		$(this).stop(true,false).fadeTo("show",0.4);
	});
	
	$(".banner-box").slide({
		titCell:".hd ul",
		mainCell:".bd ul",
		effect:"fold",
		interTime:3500,
		delayTime:500,
		autoPlay:true,
		autoPage:true, 
		trigger:"mouseover" 
	});

});
</script>
    <section id="main" class="home">
        <div class="container_12">
          <div id="content_bottom">
                <div class="grid_4">
                    <div class="bottom_block" id="lists">
                          
 
 <h3>产品分类</h3>
                        <ul>
                           
                                                           
                            <li>
                           
                                <a href="../cat/10017.html">果伴果酱</a>
                            </li>
                           
                                                   
                            <li>
                           
                                <a href="../cat/10029.html">珍珠、珍珠果专区</a>
                            </li>
                           
                                                   
                            <li>
                           
                                <a href="../cat/10028.html">椰果芦荟</a>
                            </li>
                           
                                                   
                            <li>
                           
                                <a href="../cat/10027.html">物料包装</a>
                            </li>
                           
                                                   
                            <li>
                           
                                <a href="../cat/10026.html">水果茶</a>
                            </li>
                           
                                                   
                            <li>
                           
                                <a href="../cat/10025.html">设备器具专区</a>
                            </li>
                           
                                                   
                            <li>
                           
                                <a href="../cat/10024.html">咖啡布丁</a>
                            </li>
                           
                                                   
                            <li>
                           
                                <a href="../cat/10023.html">红豆</a>
                            </li>
                           
                                                   
                            <li>
                           
                                <a href="../cat/10022.html">果汁</a>
                            </li>
                           
                                                   
                            <li>
                           
                                <a href="../cat/10021.html">果味粉、双皮奶</a>
                            </li>
                           
                                                   
                            <li>
                           
                                <a href="../cat/10020.html">果糖糖浆</a>
                            </li>
                           
                                                   
                            <li>
                           
                                <a href="../cat/10019.html">果泥</a>
                            </li>
                           
                                                   
                            <li>
                           
                                <a href="../cat/10016.html">茶叶</a>
                            </li>
                           
                                                   
                            <li>
                           
                                <a href="../cat/10015.html">杯子吸管</a>
                            </li>
                           
                                                   
                            <li>
                           
                                <a href="../cat/10012.html">爆爆珠</a>
                            </li>
                           
                                                   
                            <li>
                           
                                <a href="../cat/10018.html">果粒果酱</a>
                            </li>
                           
                                                   
                            <li>
                           
                                <a href="../cat/10030.html">植脂末奶精</a>
                            </li>
                           
                                               
                        </ul>
                    <!-- .news -->                    </div><!-- .about_as -->
                </div><!-- .grid_4 -->
                
                <div class="grid_4">
                    <div class="bottom_block about_as lh-25">
                        <h3>关于我们</h3>
                        浙江绍兴市妙斯食品商行是一家专业的珍珠奶茶原料、冷冻品休闲小吃原料、奶茶店开店设备、器具器皿供应商。集原料供应，技术开发，开店辅导，品牌策划，于一体的全资民营商行。公司秉承“以质量求生存，以品种图发展”的方针，不断提高产品质量，完善产品品种，满足市场需求。现我们商行已经有包括：珍珠，植脂末，果糖，果粉，果汁，果酱，果泥，果粒，手抓饼，水果茶，咖啡，红茶，绿茶，乌龙茶，冷冻品小吃，珍珠奶茶设备，小吃设备，奶茶器皿等千余种产品。                        <a href="../page/1003.html">&nbsp;更多>></a>
                        <div class="clear-20"></div>
                    </div><!-- .about_as -->
                </div><!-- .grid_4 -->

                <div class="grid_4">
                    <div class="bottom_block news">
                        
 <h3>最新资讯</h3>
                        <ul>
                           
                            <li>
                                
                                <a href="../post/1013.html">开奶茶店需要多少钱?</a>
                            </li>
                        
                            <li>
                                
                                <a href="../post/1012.html">通知</a>
                            </li>
                                                    
                        </ul>
                   <!-- .news -->                </div><!-- .grid_4 -->
                <div class="clear"></div>
            </div><!-- #content_bottom -->
            
            <div class="clear-20"></div>
       
                    
     <div id="content">
                <div class="grid_12">
                    <h2 class="product-title">热门产品</h2>
                </div><!-- .grid_12 -->

                <div class="clear"></div>

                <div class="products">
                            <article class="grid_3 article">
                        <img class="sale" src="../static/milk/img/top.png" alt="Sale">
                        <div class="img">
                            <a href="../post/1114.html">
                            <img src="../file/pic/dh/1207" alt="植脂末奶精" title="植脂末奶精" />                            </a>
                        </div><!-- .prev -->

                        <h3 class="title">植脂末奶精</h3>
             
                    </article><!-- .grid_3.article -->
                                <article class="grid_3 article">
                        <img class="sale" src="../static/milk/img/top.png" alt="Sale">
                        <div class="img">
                            <a href="../post/1113.html">
                            <img src="../file/pic/dh/1205" alt="珍珠" title="珍珠" />                            </a>
                        </div><!-- .prev -->

                        <h3 class="title">珍珠</h3>
             
                    </article><!-- .grid_3.article -->
                                <article class="grid_3 article">
                        <img class="sale" src="../static/milk/img/top.png" alt="Sale">
                        <div class="img">
                            <a href="../post/1112.html">
                            <img src="../file/pic/dh/1203" alt="珍珠果" title="珍珠果" />                            </a>
                        </div><!-- .prev -->

                        <h3 class="title">珍珠果</h3>
             
                    </article><!-- .grid_3.article -->
                                <article class="grid_3 article">
                        <img class="sale" src="../static/milk/img/top.png" alt="Sale">
                        <div class="img">
                            <a href="../post/1111.html">
                            <img src="../file/pic/dh/1201" alt="椰果果味酱" title="椰果果味酱" />                            </a>
                        </div><!-- .prev -->

                        <h3 class="title">椰果果味酱</h3>
             
                    </article><!-- .grid_3.article -->
                                <article class="grid_3 article">
                        <img class="sale" src="../static/milk/img/top.png" alt="Sale">
                        <div class="img">
                            <a href="../post/1110.html">
                            <img src="../file/pic/dh/1199" alt="椰果果粒" title="椰果果粒" />                            </a>
                        </div><!-- .prev -->

                        <h3 class="title">椰果果粒</h3>
             
                    </article><!-- .grid_3.article -->
                                <article class="grid_3 article">
                        <img class="sale" src="../static/milk/img/top.png" alt="Sale">
                        <div class="img">
                            <a href="../post/1109.html">
                            <img src="../file/pic/dh/1197" alt="糖水芦荟粒" title="糖水芦荟粒" />                            </a>
                        </div><!-- .prev -->

                        <h3 class="title">糖水芦荟粒</h3>
             
                    </article><!-- .grid_3.article -->
                                <article class="grid_3 article">
                        <img class="sale" src="../static/milk/img/top.png" alt="Sale">
                        <div class="img">
                            <a href="../post/1108.html">
                            <img src="../file/pic/dh/1195" alt="冰糖芦荟" title="冰糖芦荟" />                            </a>
                        </div><!-- .prev -->

                        <h3 class="title">冰糖芦荟</h3>
             
                    </article><!-- .grid_3.article -->
                                <article class="grid_3 article">
                        <img class="sale" src="../static/milk/img/top.png" alt="Sale">
                        <div class="img">
                            <a href="../post/1107.html">
                            <img src="../file/pic/dh/1193" alt="雪克杯" title="雪克杯" />                            </a>
                        </div><!-- .prev -->

                        <h3 class="title">雪克杯</h3>
             
                    </article><!-- .grid_3.article -->
                                                   <div class="clear"></div>
                </div><!-- .products -->
                <div class="clear"></div>
            </div><!-- #content -->

                    
            <div class="clear"></div>

        </div><!-- .container_12 -->
    </section><!-- #main.home -->
    
 <footer>
        <div class="footer_navigation">
            <div class="container_12">
                <div class="grid_3">
                     <h3>联系我们</h3>
                    <ul class="f_contact">
                        <li>浙江绍兴市越城区小江桥河沿48号</li>
                        <li>0575-88400521，13819505473</li>
                        <li>1348600779@qq.com</li>
                    </ul><!-- .f_contact -->
                </div><!-- .grid_3 -->

                <div class="grid_3">
                    <h3>公司信息</h3>
                    <nav class="f_menu">
                        <ul>
                            <li><a href="#">关于我们</a></li>
                            <li><a href="#">关于产品</a></li>
                            <li><a href="#">公司地址</a></li>
                            <li><a href="#">支付方式</a></li>
                        </ul>
                    </nav><!-- .private -->
                </div><!-- .grid_3 -->

                <div class="grid_3">
                    <h3>顾客服务</h3>
                    <nav class="f_menu">
                        <ul>
                            <li><a href="#">联系方式</a></li>
                            <li><a href="#">反馈</a></li>
                            <li><a href="#">Faq</a></li>
                            <li><a href="#">网站地图</a></li>
                        </ul>
                    </nav><!-- .private -->
                </div><!-- .grid_3 -->

                <div class="grid_3">
                    <h3>反馈建议</h3>
                    <nav class="f_menu">
                        <ul>
                            <li><a href="#">联系我们</a></li>
                            <li><a href="#">反馈历史</a></li>
                            <li><a href="#">期望列表</a></li>
                            <li><a href="#">新闻中心</a></li>
                        </ul>
                    </nav><!-- .private -->
                </div><!-- .grid_3 -->

 
            </div><!-- .container_12 -->
        </div><!-- .footer_navigation -->
    </footer>
    <script type="text/javascript" src="../js/custom/analyst.min.js"></script>
<script>
_fa.init();
</script>   
<div class="go-top dn" id="go-top">
    <a href="javascript:;" class="uc-2vm"></a>
	<div class="uc-2vm-pop dn">
		<div class="logo-2wm-box">
			<img src="../static/milk/img/gototop/weixin.jpg" alt="" width="240" height="240">
		</div>
	</div>
    <a href="#" target="_blank" class="feedback"></a>
    <a href="javascript:;" class="go"></a>
</div>

<script>
$(function(){
	$(window).on('scroll',function(){
		var st = $(document).scrollTop();
		if( st>200 ){
			if( $('#main-container').length != 0  ){
				var w = $(window).width(),mw = $('#main-container').width();
				if( (w-mw)/2 > 70 )
					$('#go-top').css({'left':(w-mw)/2+mw+20});
				else{
					$('#go-top').css({'left':'auto'});
				}
			}
			$('#go-top').fadeIn(function(){
				$(this).removeClass('dn');
			});
		}else{
			$('#go-top').fadeOut(function(){
				$(this).addClass('dn');
			});
		}	
	});
	$('#go-top .go').on('click',function(){
		$('html,body').animate({'scrollTop':0},500);
	});

	$('#go-top .uc-2vm').hover(function(){
		$('#go-top .uc-2vm-pop').removeClass('dn');
	},function(){
		$('#go-top .uc-2vm-pop').addClass('dn');
	});
});
</script>
<script src="../static/milk/js/milk.js"></script>
</body>
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=utf-8" /><!-- /Added by HTTrack -->
</html>
