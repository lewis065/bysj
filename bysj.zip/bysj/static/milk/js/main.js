$(document).ready(function() {
    // SelectBox
    $('select').selectBox();
       
    // Cart
    $(function() {
	$('#cart_nav').hover(
            function(){
                var self = this;
                this.hoverAnimationTimeout = setTimeout(function () {
                    $(self).find('.cart_li').transition({ background: '#eb6445', color: '#fff', paddingRight: '10px'});
                    $(self).find('.cart_cont').fadeIn();
                    $(self).find('.view_cart').transition({ left: '0' });
                    $(self).find('.checkout').transition({ left: '0', delay: 200 });
                }, 200);
	    }, function(){
                clearTimeout(this.hoverAnimationTimeout);
                $(this).find('.cart_li').transition({ background: 'none', color: '#444', paddingRight: '0' });
                $(this).find('.cart_cont').fadeOut();
                $(this).find('.view_cart').transition({ left: '315px', delay: 400 });
                $(this).find('.checkout').transition({ left: '147px', delay: 400 });
	});
    });
    
    // Menu
    $('.parent').hover(function(){
        var self = this;
        this.hoverAnimationTimeout = setTimeout(function() {
            $(self).find('.sub').slideDown();
        }, 200);
     }, function(){
            clearTimeout(this.hoverAnimationTimeout);
            $(this).find('.sub').slideUp();
    });

    // Social
    $('.soc a').hover(function(){
        var self = this;
        this.hoverAnimationTimeout = setTimeout(function() {
            $(self).transition({ rotate: '360', x: 0 });
        }, 200);
     }, function(){
            clearTimeout(this.hoverAnimationTimeout);
            $(this).transition({ rotate: '0' });
    });

    // Carousel
    $(function() {
        $('#listing').carouFredSel({
            prev: '#prev_c1',
            next: '#next_c1',
            scroll: 1,
            auto: false
        });
        $('#list_banners').carouFredSel({
            prev: '#ban_next',
            next: '#ban_prev',
            pagination  : "#ban_pagination",
            scroll: 1,
            auto: false
        });
        $('#thumblist').carouFredSel({
	    prev: '#img_prev',
	    next: '#img_next',
            pagination  : '#pagination',
	    auto: false
	});
        $(window).resize();
    });
    

    
    // Tabs
    $('#wrapper_tab a').click(function() {
	if ($(this).attr('class') != $('#wrapper_tab').attr('class') ) {
	    $('#wrapper_tab').attr('class',$(this).attr('class'));
	}
        return false;
    });
     
});
