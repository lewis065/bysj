<?php 
session_start(); 
error_reporting(0);
	 $c_path = 'model/model.php';
	 require($c_path);
	 $model = new $c_name();
	 $model->$method($key); 
?>