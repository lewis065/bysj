<?php
session_start();
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">
<head>
<meta http-equiv="Content-Type" content="text/html;charset=UTF-8">
<title>后台管理</title>
<link href="css/style.css" rel="stylesheet" type="text/css" />
</head>
<body>
 <?php if(isset($_SESSION['online'])&&$_SESSION['online']==1){?>
<div id="header"></div>
<div id="maintitle">后台管理</div>
<div id="left">
 <?php include("templates/back_left.html");?>
</div>
<div id="right">
  <?php

            if(isset($_GET['class'])){
            	$class=$_GET['class'];
            	if($class=="products"){
            		include("templates/products.php");
            	}else if($class=="pictures"){
            		include("templates/pictures.html");
            	}else if($class=="products_up"){
            		include("templates/products_add.html");
            	}else if($class=="products_mo"){
            		include("templates/products_upd.php");
            	}else if($class=="products_de"){
            		include("../system/products_de.php");
            	}else if($class=="pictures_up"){
            		include("templates/pictures_add.html");
            	}else if($class=="pictures_de"){
            		include("../system/article_gl.php");
            	}else if($class=="article"){
            		include("templates/article.html");
            	}
            }else{
            		include("templates/products.php");
            } 
}else{
	echo"<script type='text/javascript'>alert ('非法访问！')
	         location='log-in.php'
	      </script>"; 
}
  ?>
  </div>
</body>
</html>