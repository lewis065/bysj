<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>登录</title>
<link href="css/login_style.css" rel="stylesheet" type="text/css" />
 <script src="../js/admin/login_check.js"></script>
</head>
<body>
<div id="center" align="center">



  <div id="logdiv">
  <div id="left"><img src="image/miaosi.png" width="300" height="240" alt="Tea and milk"></div>
    <div id="right"><form name="LoginForm" method="post" action="login.php" onSubmit="return InputCheck(this)">
   <table width="400" border="0" cellspacing="20" bgcolor="#EEEEEE">
      <tr>
         <td><img src="image/user.PNG" width="30" height="30"/></td>
         <td><input  name="username" type="text" class="input"  /></td>

      </tr>
      <tr>
         <td><img src="image/pass.PNG" width="30" height="30"/></td> 
         <td> <input  name="password" type="password"/></td>
      </tr>
      <tr>
         <td><img src="image/check.PNG" width="30" height="30"/></td>
         <td> <input  name="checkcode" type="text" id="checkcode"/>点击图片刷新</td><td><img  title="点击刷新" src="code.php" align="absbottom" onclick="this.src='code.php?'+Math.random();"></img></td>
      </tr>
      <tr>
         <td></td>
         <td align="center"> <input type="submit" name="submit" value="  确 定  "  /></td>
      </tr>
   </table>
</form>
    </div>

  </div>
</div>
</body>
</html>


