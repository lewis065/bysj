function products_check(form){
	 if(form.name.value==""){
		alert("产品名称不能为空");
		form.name.focus();
		return false;
	}else if(form.type.value=="===请选择==="){
		alert("产品类型不能为空");
		form.type.focus();
		return false;
	}else if(form.file.value==""){
		alert("请选择图片!");
		form.file.focus();
		return false;
	}else if(form.hot.value==""){
		alert("请选择是否为热门产品!");
		form.hot.focus();
		return false;
	}else if(form.show.value==""){
		alert("请选择是否在首页展示!");
		form.show.focus();
		return false;
	}
}