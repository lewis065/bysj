function check(){
var title_input=document.getElementById("title");//获取标题输入框
var title_leave=document.getElementById("t_leave");//获取标题字数限制对象
var max_title_length=40;//定义标题最大长度
/*设置标题字数限制函数*/
title_input.onkeydown=function(){
    if(title_input.value.length>max_title_length){
    	title_input.value=title_input.value.substring(0,max_title_length);
    }
}
title_input.onkeyup=function(){
	if(title_input.value.length<=max_title_length){
		title_leave.value=max_title_length-title_input.value.length;
	}
}
}