function pictures_check(form){
if(form.file.value==""){
		alert("请选择图片!");
		form.file.focus();
		return false;
	}
}