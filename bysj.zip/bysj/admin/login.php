<?php 
session_start(); 
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>用户登录</title>
<link href="css/login_style.css" rel="stylesheet" type="text/css" />
</head>

<body>
<div id="content" align="center">
  <?php
error_reporting(0);

//登录
if(!isset($_POST['submit'])){
   echo"<script type='text/javascript'>alert ('非法访问！')
	        location='log-in.php' 
			</script>";}
$validate="";
if(isset($_POST["checkcode"])){
$validate=$_POST["checkcode"];
echo "You enter:".$_POST["checkcode"]."<br>state：";
if($validate!=$_SESSION["authnum_session"]){
//判断session值与用户输入的验证码是否一致;
echo "<script type='text/javascript'>alert ('验证码错误！')
	         location='log-in.php'
	      </script>"; 
}else{
	include('system/inc.php');
$conn = mysql_connect($servername,$username,$password);
$okdatabase = mysql_select_db($dbname);
$user =$_POST['username'];
$pass =MD5($_POST['password']);
//检测用户名及密码是否正确
$check_query = mysql_query("select user from user where user='$user' and pass='$pass'",$conn);
if(($row = mysql_fetch_row($check_query))!=null){
    //登录成功
    echo "<script language='javascript'>";
	$_SESSION['online']=1;
    echo "window.location.href='backstage.php'";
    echo "</script>"; 
    
    exit;
} else {
     echo "<script type='text/javascript'>alert ('登录失败！')
	         location='log-in.php'
	      </script>"; 
}
}
} 
?>

</div>
</body>
</html>