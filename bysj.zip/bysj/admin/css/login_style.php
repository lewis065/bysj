@charset "utf-8";
#header {
	background-color: #666;
	height: 50px;
	width: 467px;
	color: #FFF;
	font-size: 36px;
	font-family: "方正琥珀简体";
	font-style: normal;
	font-weight: bold;
	text-align: center;
	margin-top: 100px;
}
#content {
	background-color: #CCCCCC;
	height: 120px;
	width: 467px;
	background-image: url(images/sym2.PNG);
	background-repeat: no-repeat;
	background-position: center;
}
#enter {
	height: 100px;
	width: 467px;
}

#input {
	background-color: #CCC;
	height: auto;
	width: 467px;
}
.txt {
	font-size: 18px;
	color: #000;
	font-style: normal;
	text-decoration: blink;
}
#center form table tr td #checkcode {
	width: 110px;
}
