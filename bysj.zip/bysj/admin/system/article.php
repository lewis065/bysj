<?php
header("content-type:text/html;charset=utf-8");
error_reporting(0);
include("inc.php");
$conn = mysql_connect($servername,$username,$password);
$okdatabase = mysql_select_db($dbname);
$title=$_POST['title'];
$article=addslashes($_POST['p_content']);
$sql="insert into news(title,content) values('$title','$article');";
mysql_query($sql,$conn);
$rowDeleted=mysql_affected_rows();
if ($rowDeleted > 0){ 
	echo "<script type='text/javascript'>alert ('上传成功！')
	         location='../backstage.php?class=article'
	      </script>";
} else {
	echo"<script type='text/javascript'>alert ('上传失败！')
	         location='../backstage.php?class=article'
	      </script>";;
		
}
?>