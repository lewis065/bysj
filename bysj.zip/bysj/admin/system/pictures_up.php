<div id="result" align="center">
<?php  
error_reporting(0);
include("inc.php");
$conn = mysql_connect($servername,$username,$password);
$okdatabase = mysql_select_db($dbname);
if ($_FILES["file"]["error"] > 0) 
{ 
echo "Return Code: " . $_FILES["file"]["error"] . "<br />"; 
} else { 
if (file_exists("pictures/" . $_FILES["file"]["name"])){ 
echo "<script type='text/javascript'>alert ('文件已存在！')
	         location='../backstage.php?class=pictures_up'
	      </script>";
} else { 
if(move_uploaded_file($_FILES["file"]["tmp_name"], 
"pictures/" . $_FILES["file"]["name"])){
$sql="insert into picture (img) values ('{$_FILES['file']['name']}')";
mysql_query($sql,$conn); 
$row=mysql_affected_rows();
if($row >0){
	echo "<script type='text/javascript'>alert ('上传成功！')
	         location='../backstage.php?class=pictures'
	      </script>";
}else{echo "<script type='text/javascript'>alert ('插入数据库失败！')
	         location='../backstage.php?class=pictures_up'
			 </script>";
}
}else{
	echo "<script type='text/javascript'>alert ('上传失败！')
	        location='../backstage.php?class=pictures_up'
	      </script>"; 
		  }
}
}

?> 
</div>