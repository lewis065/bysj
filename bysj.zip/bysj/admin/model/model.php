<?php
class selectclass{
	function productsinfo($key){	
	 include("system/inc.php");
     $conn = mysql_connect($servername,$username,$password);
     $okdatabase = mysql_select_db($dbname);	
	 $sql="select * from milkinfo";
     $result=mysql_query($sql,$conn);    
     $row=mysql_fetch_row($result); 
     if($row!=null){			 
          $data = 'success';
	 }else{
		  $data = 'failed';
     }
     require('view/view.php');
     $view = new proinfo_show();
     $view->display($data,$row);
	 //释放资源,关闭连接 
     mysql_free_result($result);
     mysql_close();
	}
}
?>