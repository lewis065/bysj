<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">
<head>
<meta http-equiv="Content-Type" content="text/html;charset=UTF-8">
<link href="css/products.css" rel="stylesheet" type="text/css" />
<script src="js/products.js"></script>
</head>
<body>
<div class="products" >
<form method="post" action="system/products_upd.php" enctype="multipart/form-data">
<div id="products_name">
<span>产品名称：
  <input type="text" name="name" id="name" value=""></span>
  </div>
  <div id="protype">
<span>产品类别：
  <select id="type" name="type">
     <option selected>===请选择===</option>
     <option value="果伴果酱">果伴果酱</option>
     <option value="珍珠、珍珠果">珍珠、珍珠果</option>
     <option value="椰果芦荟">椰果芦荟</option>
     <option value="物料包装">物料包装</option>
     <option value="水果茶">水果茶</option>
     <option value="设备器具">设备器具</option>
     <option value="咖啡布丁">咖啡布丁</option>
     <option value="红豆">红豆</option>
     <option value="果汁">果汁</option>
     <option value="果味粉、双皮奶">果味粉、双皮奶</option>
     <option value="果糖糖浆">果糖糖浆</option>
     <option value="果泥">果泥</option>
     <option value="茶叶">茶叶</option>
     <option value="杯子吸管">杯子吸管</option>
     <option value="爆爆珠">爆爆珠</option>
     <option value="果粒果酱">果粒果酱</option>
     <option value="植脂末奶精">植脂末奶精</option>
  </select>
</span>
</div>
<div id="propic">
<span>图片：
  <input  type = "file" name="file" id="file" value=""/>
</span>
</div>
 <div id="hotpro">
<span>热门产品：
<input type="radio" name="hot" value="是" />是
<input type="radio" name="hot" value="否" />否
</span>
</div>
<div id="showindex">
<span>首页展示：
<input type="radio" name="show" value="是" />是
<input type="radio" name="show" value="否" />否
</span>
</div>
<div id="btn2">
<input type = "submit" value="保存" onclick="return products_check(this.form)">
<input type = "reset" value="清除">
</div>
</form>
</div>
</body>
</html>