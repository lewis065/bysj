<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">
<head>
<meta http-equiv="Content-Type" content="text/html;charset=UTF-8">
<link href="css/right.css" rel="stylesheet" type="text/css" />
</head>
<body>
<div id="tool">
   <span><a href="../admin/backstage.php?class=products_up"><img src="image/add.png" width="25" height="20"/>添加</a></span>
   <span><a href="../admin/backstage.php?class=products_mo&id="><img src="image/modify.png" width="25" height="20"/>修改</a></span>
   <span><a href="../admin/backstage.php?class=products_de&id="><img src="image/delete.png" width="25" height="20"/>删除</a></span>
</div>
<div id="info">
<table width="100%">
    <thead>
       <th width='10%'>序号</th>
       <th width='20%'>产品名称</th>
       <th width='30%'>产品图片</th>
       <th width='10%'>产品类别</th>
       <th width='10%'>热门产品</th>
       <th width='10%'>首页展示</th>
       <th width='10%'>操作</th>
    </thead>
    <tbody>
<?php
$c_name='selectclass';
$method = 'productsinfo';
$key="";
include("controller/controller.php");			
?>
    </tbody>
</table>
</div>
</body>
</html>
