<?php
session_start();
class proinfo_show{
	public function display($data,$row) {
		if($data=='success'){
        echo"<foreach name='row' item='a'>
        <tr>
        <td>$a.id</td>
        <td>$a.name</td>
        <td>$a.img</td>
        <td>$a.protype</td>
        <td>$a.hot</td>
        <td>$a.isshow</td>
        </tr>
        </foreach>";
		}else{}
	
   }
}
?>